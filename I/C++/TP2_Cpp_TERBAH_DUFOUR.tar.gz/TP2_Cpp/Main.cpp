
#include <iostream>

#include "Interface.h"

int main(int argc, const char** argv) 
{
    Interface interface;
    interface.Run ( );
    return 0;
}